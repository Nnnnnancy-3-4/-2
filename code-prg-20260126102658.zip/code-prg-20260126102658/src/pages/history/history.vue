<template>
  <div class="flex-col page">
    <div class="flex-row justify-end group">
      <img
        class="image"
        src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=fad056f4959b867fbe330b5811a43bce.png"
      />
      <img
        class="image_2 ml-5"
        src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=74cd59d89c4cbcd2d3c47036a2a3cf19.png"
      />
      <img
        class="image_3 ml-5"
        src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=b48e7a5b99ca96148f892dbe7c699749.png"
      />
    </div>
    <div class="flex-row justify-between items-center group view">
      <div class="flex-row items-center">
        <div class="flex-col shrink-0 group_2">
          <span class="font text">History</span>
          <div class="divider mt-3"></div>
        </div>
        <span class="ml-24 font text_2">Recruiting</span>
      </div>
      <img
        class="image_4"
        src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=aecf115b750a23a95cab9300ba0c7f77.png"
      />
    </div>
    <div class="flex-row equal-division section">
      <div class="flex-col justify-start items-center image-wrapper equal-division-item">
        <img
          class="image_5"
          src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=9a73e0110aed74c3185ad6b8202303e9.png"
        />
      </div>
      <div class="flex-col justify-start items-center image-wrapper equal-division-item">
        <img
          class="image_6"
          src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=cba036c223a6c5a6abe8dec073b11fd7.png"
        />
      </div>
      <div class="flex-col justify-start items-center image-wrapper image-wrapper_2">
        <img
          class="image_6"
          src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=befba4218423dfb643d245b31db17a50.png"
        />
      </div>
      <div class="flex-col justify-start items-center image-wrapper equal-division-item">
        <img
          class="image_6"
          src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=a0ffa35c9f6aa567d439ec7ac80fbec0.png"
        />
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    components: {},
    props: {},
    data() {
      return {};
    },

    methods: {},
  };
</script>

<style scoped lang="css">
  .ml-5 {
    margin-left: 0.31rem;
  }
  .mt-3 {
    margin-top: 0.19rem;
  }
  .page {
    padding: 1.13rem 0.5rem 2.13rem;
    background-color: #131415;
    mix-blend-mode: NOTTHROUGH;
    width: 100%;
    overflow-y: auto;
    overflow-x: hidden;
    height: 100%;
  }
  .group {
    padding: 0 0.5rem;
  }
  .image {
    mix-blend-mode: NOTTHROUGH;
    width: 1.06rem;
    height: 0.69rem;
  }
  .image_2 {
    mix-blend-mode: NOTTHROUGH;
    width: 0.94rem;
    height: 0.69rem;
  }
  .image_3 {
    width: 1.5rem;
    height: 0.71rem;
  }
  .view {
    margin-top: 1.5rem;
  }
  .group_2 {
    width: 4.64rem;
  }
  .font {
    font-size: 1.25rem;
    font-family: Inter;
    line-height: 1.21rem;
  }
  .text {
    color: #ffffff;
    font-weight: 700;
    line-height: 1.22rem;
  }
  .divider {
    margin-right: 0.13rem;
    background-color: #9056ff;
    mix-blend-mode: NOTTHROUGH;
    height: 0.25rem;
  }
  .text_2 {
    color: #ffffff80;
  }
  .image_4 {
    border-radius: 1052981.25rem;
    width: 2.5rem;
    height: 2.5rem;
  }
  .equal-division {
    margin-top: 94.88rem;
  }
  .section {
    padding: 0.5rem;
    background-color: #212225cc;
    border-radius: 1.5rem;
    mix-blend-mode: NOTTHROUGH;
    filter: drop-shadow(0rem 0.75rem 0.75rem #00000066);
    backdrop-filter: blur(0.63rem);
    border-left: solid 0.031rem #ffffff33;
    border-right: solid 0.031rem #ffffff33;
    border-top: solid 0.031rem #ffffff33;
    border-bottom: solid 0.031rem #ffffff33;
  }
  .image-wrapper {
    flex: 1 1 5.36rem;
  }
  .equal-division-item {
    padding: 0.75rem 0;
    border-radius: 1rem;
    height: 3.25rem;
  }
  .image_5 {
    width: 1.63rem;
    height: 1.63rem;
  }
  .image_6 {
    width: 1.75rem;
    height: 1.75rem;
  }
  .image-wrapper_2 {
    padding: 0.75rem 0;
    background-image: radial-gradient(41.2% 41.2% at 50% 75%, #9456ff66 0%, #56349900 100%);
    border-radius: 1rem;
    mix-blend-mode: NOTTHROUGH;
    height: 3.25rem;
  }
</style>