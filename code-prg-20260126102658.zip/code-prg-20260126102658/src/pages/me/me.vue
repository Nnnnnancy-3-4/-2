<template>
  <div class="flex-col page">
    <div class="flex-col self-stretch">
      <div class="flex-col justify-start items-center relative">
        <img
          class="image"
          src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=40b010fb75d67779654f77099f9cb0e1.png"
        />
        <img
          class="image pos"
          src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=3db1d683b75f24769f2776e4ae1e3d7c.png"
        />
        <div class="flex-col section pos_2">
          <div class="flex-row justify-end">
            <img
              class="image_2"
              src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=fad056f4959b867fbe330b5811a43bce.png"
            />
            <img
              class="image_3 ml-5"
              src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=74cd59d89c4cbcd2d3c47036a2a3cf19.png"
            />
            <img
              class="image_4 ml-5"
              src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=b48e7a5b99ca96148f892dbe7c699749.png"
            />
          </div>
          <div class="mt-24 flex-row justify-center items-start relative group">
            <div class="flex-col group_2">
              <div class="flex-col justify-start items-start relative group_3">
                <div class="flex-col justify-start items-center relative image-wrapper">
                  <img
                    class="image_6"
                    src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=4694e06e622bcf1a7c3510f3bcc2468b.png"
                  />
                </div>
                <img
                  class="image_5 pos_4"
                  src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=cfbca1a90da9fa03e69cc92230756839.png"
                />
              </div>
              <div class="mt-18 flex-col justify-start relative group_3 view">
                <span class="text">Detective_007</span>
                <span class="font text_2 pos_5">ID: 893402</span>
              </div>
            </div>
            <img
              class="image_5 pos_3"
              src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=aecf115b750a23a95cab9300ba0c7f77.png"
            />
          </div>
        </div>
      </div>
      <div class="flex-row equal-division">
        <div class="flex-col section_2 equal-division-item">
          <span class="self-center font_2">42</span>
          <div class="mt-12 flex-col items-start self-stretch group_4">
            <span class="font_3 text_3 text_4">Hours</span>
            <span class="font_3 text_6">Played</span>
          </div>
        </div>
        <div class="ml-12 flex-col section_2 equal-division-item">
          <span class="self-center font_2">12</span>
          <div class="mt-12 flex-col self-stretch group_5">
            <span class="self-start font_3 text_3">Scripts</span>
            <span class="self-center font_3 text_6">Done</span>
          </div>
        </div>
        <div class="ml-12 flex-col items-center section_2 section_3">
          <span class="font_2">5</span>
          <span class="font_3 text_3 text_5 mt-23">Endings</span>
        </div>
      </div>
    </div>
    <div class="flex-col self-stretch group_6">
      <span class="self-start font_4 text_3">my Scripts</span>
      <div class="mt-10 flex-row items-start self-stretch section_5">
        <div class="relative section_4"></div>
        <div class="ml-16 shrink-0 section_6"></div>
      </div>
    </div>
    <div class="flex-col self-stretch group_7">
      <span class="self-start font_4 text_3">my Preferences</span>
      <div class="mt-10 flex-col justify-start self-stretch relative group_8">
        <div class="section_7"></div>
        <div class="flex-col pos_6">
          <div class="flex-row justify-between items-center list-item" v-for="(item, index) in items" :key="index">
            <div class="flex-row items-center">
              <img
                class="shrink-0 image_7"
                src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=f23b07f5c721eeffc6c7ccae75e8c657.png"
              />
              <div class="flex-col shrink-0 group_9 ml-17">
                <span class="font_5">Preference Settings</span>
                <span class="mt-2 font text_7">Audio, Notifications, Display</span>
              </div>
            </div>
            <img
              class="image_8"
              src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=d6d258b0782836c03aea52b9728d5818.png"
            />
          </div>
        </div>
      </div>
    </div>
    <span class="self-center font_3 text_11">v1.0.0 (MVP Build)</span>
    <div class="flex-row equal-division_2 section_8">
      <div class="flex-col justify-start items-center image-wrapper_2 equal-division-item_2">
        <img
          class="image_10"
          src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=9a73e0110aed74c3185ad6b8202303e9.png"
        />
      </div>
      <div class="flex-col justify-start items-center image-wrapper_2 equal-division-item_2">
        <img
          class="image_11"
          src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=cba036c223a6c5a6abe8dec073b11fd7.png"
        />
      </div>
      <div class="flex-col justify-start items-center image-wrapper_2 equal-division-item_2">
        <img
          class="image_11"
          src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=ad6a078559f01e357a5d81ea0e1e9807.png"
        />
      </div>
      <div class="flex-col justify-start items-center image-wrapper_2 image-wrapper_3">
        <img
          class="image_11"
          src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=a0ffa35c9f6aa567d439ec7ac80fbec0.png"
        />
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    components: {},
    props: {},
    data() {
      return {
        items: [null, null, null, null],
      };
    },

    methods: {},
  };
</script>

<style scoped lang="css">
  .ml-5 {
    margin-left: 0.31rem;
  }
  .mt-23 {
    margin-top: 1.44rem;
  }
  .ml-17 {
    margin-left: 1.06rem;
  }
  .page {
    padding-bottom: 2.13rem;
    background-color: #131415;
    mix-blend-mode: NOTTHROUGH;
    width: 100%;
    overflow-y: auto;
    overflow-x: hidden;
    height: 100%;
  }
  .image {
    mix-blend-mode: NOTTHROUGH;
    filter: blur(0.94rem);
    width: 100vw;
    height: 73.0667vw;
  }
  .pos {
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
  }
  .section {
    padding: 1.13rem 1rem 1.38rem;
    background-image: linear-gradient(180deg, #0a001c 9%, #4c205566 56.4%, #121314 100%);
    mix-blend-mode: NOTTHROUGH;
    backdrop-filter: blur(0.31rem);
  }
  .pos_2 {
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
  }
  .image_2 {
    mix-blend-mode: NOTTHROUGH;
    width: 1.06rem;
    height: 0.69rem;
  }
  .image_3 {
    mix-blend-mode: NOTTHROUGH;
    width: 0.94rem;
    height: 0.69rem;
  }
  .image_4 {
    width: 1.5rem;
    height: 0.71rem;
  }
  .group {
    padding-top: 1.5rem;
  }
  .group_2 {
    width: 8.13rem;
  }
  .group_3 {
    padding-bottom: 0.25rem;
  }
  .image-wrapper {
    background-image: linear-gradient(180deg, #6a1cff 0%, #b038f5 100%);
    mix-blend-mode: NOTTHROUGH;
    box-shadow: 0rem 0rem 0.75rem 0.25rem #9056ff36;
    border-radius: 50%;
    width: 7rem;
  }
  .image_6 {
    mix-blend-mode: NOTTHROUGH;
    border-radius: 50%;
    width: 7rem;
    height: 7rem;
  }
  .image_5 {
    border-radius: 1052981.25rem;
    width: 2.5rem;
    height: 2.5rem;
  }
  .pos_4 {
    position: absolute;
    right: 0.88rem;
    bottom: 0;
  }
  .view {
    margin-left: 0.13rem;
  }
  .text {
    color: #ffffff;
    font-size: 1.13rem;
    font-family: Inter;
    font-weight: 700;
    line-height: 1.63rem;
    text-align: center;
  }
  .font {
    font-size: 0.69rem;
    font-family: Inter;
    line-height: 1.25rem;
    color: #99a1af;
  }
  .text_2 {
    color: #6a7282;
    line-height: 0.75rem;
    text-align: right;
    width: 3.5rem;
  }
  .pos_5 {
    position: absolute;
    left: 50%;
    bottom: 0;
    transform: translateX(-50%);
  }
  .pos_3 {
    position: absolute;
    right: 0;
    top: 0;
  }
  .equal-division {
    margin: 0 1rem;
  }
  .section_2 {
    flex: 1 1 6.65rem;
  }
  .equal-division-item {
    padding: 1.75rem 1rem 1.44rem;
    background-color: #1e1f21;
    border-radius: 1rem;
    mix-blend-mode: NOTTHROUGH;
    height: 7rem;
    border-left: solid 0.031rem #ffffff33;
    border-right: solid 0.031rem #ffffff33;
    border-top: solid 0.031rem #ffffff33;
    border-bottom: solid 0.031rem #ffffff33;
  }
  .font_2 {
    font-size: 1.5rem;
    font-family: Inter;
    line-height: 1.11rem;
    font-weight: 900;
    color: #b68bff;
  }
  .group_4 {
    padding: 0 1rem;
    overflow: hidden;
    height: 2rem;
  }
  .font_3 {
    font-size: 0.69rem;
    font-family: Inter;
    line-height: 1rem;
    font-weight: 600;
    color: #99a1af;
  }
  .text_6 {
    text-transform: uppercase;
    word-break: break-all;
  }
  .group_5 {
    padding: 0 0.88rem;
    overflow: hidden;
    height: 2rem;
  }
  .section_3 {
    padding: 1.75rem 0 2.13rem;
    background-color: #1e1f21;
    border-radius: 1rem;
    mix-blend-mode: NOTTHROUGH;
    height: 7rem;
    border-left: solid 0.031rem #ffffff33;
    border-right: solid 0.031rem #ffffff33;
    border-top: solid 0.031rem #ffffff33;
    border-bottom: solid 0.031rem #ffffff33;
  }
  .group_6 {
    margin: 2.13rem 1rem 0;
  }
  .font_4 {
    font-size: 0.88rem;
    font-family: Inter;
    line-height: 1.25rem;
    font-weight: 600;
    color: #6a7282;
  }
  .text_3 {
    text-transform: uppercase;
  }
  .text_5 {
    line-height: 0.51rem;
  }
  .text_4 {
    margin-left: 0.13rem;
  }
  .section_5 {
    overflow: hidden;
    border-radius: 1rem;
    background-color: #1e1f21;
    mix-blend-mode: NOTTHROUGH;
    height: 6rem;
  }
  .section_4 {
    margin-left: -5.13rem;
    margin-top: -4.81rem;
    flex: 1 0 0;
    background-color: #672666cc;
    mix-blend-mode: NOTTHROUGH;
    filter: blur(1.88rem);
    border-radius: 50%;
    height: 8.75rem;
  }
  .section_6 {
    margin-right: -1.69rem;
    margin-top: 1.25rem;
    background-color: #9056ffcc;
    mix-blend-mode: NOTTHROUGH;
    filter: blur(1.88rem);
    border-radius: 50%;
    width: 11.88rem;
    height: 8.75rem;
  }
  .group_7 {
    margin: 2.13rem 1rem 0;
  }
  .group_8 {
    padding-bottom: 5.25rem;
  }
  .section_7 {
    background-color: #1e1f21;
    border-radius: 1rem;
    mix-blend-mode: NOTTHROUGH;
    height: 13.5rem;
    border-left: solid 0.031rem #ffffff33;
    border-right: solid 0.031rem #ffffff33;
    border-top: solid 0.031rem #ffffff33;
    border-bottom: solid 0.031rem #ffffff33;
  }
  .pos_6 {
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
  }
  .list-item {
    margin: 0 1rem;
    padding: 0.88rem 0 0.75rem;
    border-radius: 1.13rem;
  }
  .image_7 {
    border-radius: 0.63rem;
    width: 2.5rem;
    height: 2.5rem;
  }
  .group_9 {
    width: 9.55rem;
  }
  .font_5 {
    font-size: 1rem;
    font-family: Inter;
    line-height: 1.5rem;
    font-weight: 600;
    color: #ffffff;
  }
  .text_7 {
    font-size: 0.75rem;
    text-align: center;
  }
  .image_8 {
    width: 1rem;
    height: 1rem;
  }
  .text_11 {
    margin-top: 2.13rem;
    color: #4a5565;
    font-size: 0.75rem;
    font-weight: unset;
    text-align: center;
    width: 6rem;
  }
  .equal-division_2 {
    align-self: stretch;
    margin: 2.38rem 0.5rem 0;
  }
  .section_8 {
    padding: 0.5rem;
    background-color: #212225cc;
    border-radius: 1.5rem;
    mix-blend-mode: NOTTHROUGH;
    filter: drop-shadow(0rem 0.75rem 0.75rem #00000066);
    backdrop-filter: blur(0.63rem);
    border-left: solid 0.031rem #ffffff33;
    border-right: solid 0.031rem #ffffff33;
    border-top: solid 0.031rem #ffffff33;
    border-bottom: solid 0.031rem #ffffff33;
  }
  .image-wrapper_2 {
    flex: 1 1 5.36rem;
  }
  .equal-division-item_2 {
    padding: 0.75rem 0;
    border-radius: 1rem;
    height: 3.25rem;
  }
  .image_10 {
    width: 1.63rem;
    height: 1.63rem;
  }
  .image_11 {
    width: 1.75rem;
    height: 1.75rem;
  }
  .image-wrapper_3 {
    padding: 0.75rem 0;
    background-image: radial-gradient(41.2% 41.2% at 50% 75%, #9456ff66 0%, #56349900 100%);
    border-radius: 1rem;
    mix-blend-mode: NOTTHROUGH;
    height: 3.25rem;
  }
</style>