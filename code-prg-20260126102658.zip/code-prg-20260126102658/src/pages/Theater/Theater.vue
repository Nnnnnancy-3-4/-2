<template>
  <div class="flex-col page">
    <div class="flex-col justify-start items-start relative group">
      <img
        class="shrink-0 image_4"
        src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=17be6a9bf94d05b14fe3a1944be8a65c.png"
      />
      <div class="flex-col section pos">
        <div class="flex-row justify-end self-stretch">
          <img
            class="image"
            src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=fad056f4959b867fbe330b5811a43bce.png"
          />
          <img
            class="image_2 ml-5"
            src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=74cd59d89c4cbcd2d3c47036a2a3cf19.png"
          />
          <img
            class="image_3 ml-5"
            src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=b48e7a5b99ca96148f892dbe7c699749.png"
          />
        </div>
        <img
          class="self-end image_5"
          src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=1de1c53174a50b77d5ac1ab3e3d3a221.png"
        />
        <div class="flex-col self-center group_2">
          <img
            class="self-center image_6"
            src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=3d7eecc8f343191663b00c54cb84ffe1.png"
          />
          <span class="mt-12 self-stretch text">
            Welcome to
            <br />
            Parallel Theater
          </span>
        </div>
        <span class="self-stretch font text_2">
          Enter the theater to claim your new identity
          <br />
          Step into the spotlight
        </span>
        <div class="flex-col justify-start self-center section_2">
          <div class="flex-col items-center section_3">
            <span class="font_2 text_3">enter</span>
            <span class="font_2 text_3">stage</span>
          </div>
        </div>
        <span class="self-center font text_4">Matching Preferences</span>
      </div>
    </div>
    <div class="mt-84 flex-row equal-division section_4">
      <div class="flex-col justify-start items-center image-wrapper equal-division-item">
        <img
          class="image_7"
          src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=9a73e0110aed74c3185ad6b8202303e9.png"
        />
      </div>
      <div class="flex-col justify-start items-center image-wrapper image-wrapper_2">
        <img
          class="image_8"
          src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=af769405d912c7a617b6cb5df58e5807.png"
        />
      </div>
      <div class="flex-col justify-start items-center image-wrapper equal-division-item">
        <img
          class="image_8"
          src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=ad6a078559f01e357a5d81ea0e1e9807.png"
        />
      </div>
      <div class="flex-col justify-start items-center image-wrapper equal-division-item">
        <img
          class="image_8"
          src="https://ide.code.fun/api/image?token=697716e94683ce0011d99a2b&name=a0ffa35c9f6aa567d439ec7ac80fbec0.png"
        />
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    components: {},
    props: {},
    data() {
      return {};
    },

    methods: {},
  };
</script>

<style scoped lang="css">
  .ml-5 {
    margin-left: 0.31rem;
  }
  .page {
    padding-bottom: 2.13rem;
    background-color: #131415;
    mix-blend-mode: NOTTHROUGH;
    width: 100%;
    overflow-y: auto;
    overflow-x: hidden;
    height: 100%;
  }
  .group {
    padding-top: 2.63rem;
    overflow: hidden;
  }
  .image_4 {
    margin-left: -20.81rem;
    mix-blend-mode: NOTTHROUGH;
    filter: blur(0.31rem);
    width: 277.8667vw;
    height: 155.7333vw;
  }
  .section {
    padding: 1.13rem 1rem 4.38rem 2.88rem;
    background-image: linear-gradient(180deg, #0a001c 0%, #24004300 68.8%, #121314 100%);
    mix-blend-mode: NOTTHROUGH;
    backdrop-filter: blur(0.13rem);
  }
  .pos {
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
  }
  .image {
    mix-blend-mode: NOTTHROUGH;
    width: 1.06rem;
    height: 0.69rem;
  }
  .image_2 {
    mix-blend-mode: NOTTHROUGH;
    width: 0.94rem;
    height: 0.69rem;
  }
  .image_3 {
    width: 1.5rem;
    height: 0.71rem;
  }
  .image_5 {
    margin-top: 1.5rem;
    border-radius: 1052981.25rem;
    width: 2.5rem;
    height: 2.5rem;
  }
  .group_2 {
    margin-top: 2.5rem;
    width: 14rem;
  }
  .image_6 {
    width: 2.94rem;
    height: 2.25rem;
  }
  .text {
    color: #ffffff;
    font-size: 1.88rem;
    font-family: Inter;
    font-weight: 900;
    line-height: 2.38rem;
    text-align: center;
  }
  .font {
    font-size: 0.88rem;
    font-family: Inter;
    line-height: 1.25rem;
  }
  .text_2 {
    margin-top: 2.75rem;
    color: #ffffff80;
    text-align: center;
  }
  .section_2 {
    margin-top: 3.63rem;
    padding: 0.25rem 0;
    background-color: #00000033;
    mix-blend-mode: NOTTHROUGH;
    border-radius: 50%;
    width: 9rem;
  }
  .section_3 {
    margin: 0 0.25rem;
    padding: 2.63rem 0 2.38rem;
    background-image: linear-gradient(180deg, #ffffff 0%, #d9c5ffcc 100%);
    mix-blend-mode: NOTTHROUGH;
    box-shadow: 0rem 0.75rem 2rem 0.25rem #9056ff80, 0rem 0rem 1rem 0.25rem #ffffff inset;
    border-radius: 50%;
    width: 8.5rem;
  }
  .font_2 {
    font-size: 1.25rem;
    font-family: Inter;
    line-height: 1.75rem;
    font-weight: 900;
    color: #6a1cff;
  }
  .text_3 {
    text-transform: uppercase;
  }
  .text_4 {
    margin-top: 3.25rem;
    color: #ffffffcc;
    font-weight: 600;
    text-align: center;
    text-transform: uppercase;
    width: 11.06rem;
  }
  .equal-division {
    margin: 0 0.5rem;
  }
  .section_4 {
    padding: 0.5rem;
    background-color: #212225cc;
    border-radius: 1.5rem;
    mix-blend-mode: NOTTHROUGH;
    filter: drop-shadow(0rem 0.75rem 0.75rem #00000066);
    backdrop-filter: blur(0.63rem);
    border-left: solid 0.031rem #ffffff33;
    border-right: solid 0.031rem #ffffff33;
    border-top: solid 0.031rem #ffffff33;
    border-bottom: solid 0.031rem #ffffff33;
  }
  .image-wrapper {
    flex: 1 1 5.36rem;
  }
  .equal-division-item {
    padding: 0.75rem 0;
    border-radius: 1rem;
    height: 3.25rem;
  }
  .image_7 {
    width: 1.63rem;
    height: 1.63rem;
  }
  .image-wrapper_2 {
    padding: 0.75rem 0;
    background-image: radial-gradient(41.2% 41.2% at 50% 75%, #9456ff66 0%, #56349900 100%);
    border-radius: 1rem;
    mix-blend-mode: NOTTHROUGH;
    height: 3.25rem;
  }
  .image_8 {
    width: 1.75rem;
    height: 1.75rem;
  }
</style>