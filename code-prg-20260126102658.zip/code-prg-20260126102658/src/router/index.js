import Vue from 'vue';
import VueRouter from 'vue-router';
import Theater from '../pages/Theater/Theater.vue';
import History from '../pages/history/history.vue';
import Me from '../pages/me/me.vue';

Vue.use(VueRouter);

const routes = [
  {
    path: '/',
    name: 'Theater',
    component: Theater,
  },
  {
    path: '/history',
    name: 'history',
    component: History,
  },
  {
    path: '/me',
    name: 'me',
    component: Me,
  },
];

const router = new VueRouter({
  mode: 'hash',
  base: process.env.BASE_URL,
  routes,
});

export default router;